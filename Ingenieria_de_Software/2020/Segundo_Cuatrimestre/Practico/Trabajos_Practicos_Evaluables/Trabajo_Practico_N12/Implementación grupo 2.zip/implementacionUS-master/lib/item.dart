class Item {
  final id;
  final name;
  final precio;

  Item({this.id, this.name, this.precio});
}
