package com.example.realizarPedido

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
