import 'package:flutter/material.dart';
import 'package:realizarPedido/app.dart';

void main() {
  runApp(App());
}
